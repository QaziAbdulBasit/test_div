# -*- coding: utf-8 -*-
# from odoo import http


# class EFiling(http.Controller):
#     @http.route('/e_filing/e_filing', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/e_filing/e_filing/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('e_filing.listing', {
#             'root': '/e_filing/e_filing',
#             'objects': http.request.env['e_filing.e_filing'].search([]),
#         })

#     @http.route('/e_filing/e_filing/objects/<model("e_filing.e_filing"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('e_filing.object', {
#             'object': obj
#         })
