# -*- coding: utf-8 -*-
import pdb

from odoo import models, fields, api
import base64
import io
from docx import Document
from odoo import models, fields, api, SUPERUSER_ID
from odoo.tools.translate import _
import xlrd
import tempfile
import binascii
from datetime import timedelta
from odoo.addons.base.models.ir_mail_server import MailDeliveryException
from odoo.exceptions import ValidationError, UserError
from jinja2 import Markup
import os


class HREmployee(models.Model):
    _inherit = "mail.activity"

    create_task = fields.Boolean(default=False)

    def action_done(self):
        self.create_task = True
        """ Wrapper without feedback because web button add context as
        parameter, therefore setting context to feedback """
        messages, next_activities = self._action_done()
        return messages.ids and messages.ids[0] or False


class ELetter(models.Model):
    _name = 'e.letter'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'E Office'
    _order = 'letter_date desc'
    # _rec_name = 'parent_id'

    ref_no = fields.Char("Ref No", required=True, tracking=True, index=True, )
    name = fields.Char("Subject", required=True, tracking=True, index=True,
                       )
    sensitivity_id = fields.Many2one("sensitivity.table", string="Sensitivity Type")
    letter_from = fields.Char("Letter From")
    letter_no = fields.Char("Letter No")
    in_progress = fields.Boolean('Working InProgress', default=False,tracking=True, index=True,)
    docx_file = fields.Binary(string='Upload Word File')
    content = fields.Html(string='File Content')
    sender_id = fields.Many2one('res.users', string='Sender', )
    letter_date = fields.Date("Letter Date", tracking=True, index=True, )
    meeting_date = fields.Date("Meeting Date (If any)", tracking=True, index=True, )
    send_to = fields.Many2many("hr.employee", 'send_toss', 'send_to_idss', string="Send To", tracking=True,
                               index=True, )
    revisions_name = fields.Many2one("res.users", string="Revision Name", )
    version_no = fields.Char("Version No")
    parent_id = fields.Many2one("e.letter", string="If Any Previous (version)", tracking=True, index=True, )
    department_ids = fields.Many2many("hr.department", string="Departments", tracking=True, index=True, )
    # current_employee_dep = fields.Many2one("hr.department", string="Departments", tracking=True,index=True,
    #                                   compute='get_current_user_department')
    instruction = fields.Html("Instruction", tracking=True, index=True)
    employee_track_sender = fields.Many2many("res.users", 'employee_track_senders', 'employee_track_idss',
                                             string="Employee Track Sender", tracking=True, index=True, )
    employee_track = fields.Many2many("hr.employee", 'employee_trackss', 'employee_track_idss', string="Employee Track",
                                      tracking=True, index=True, )

    description = fields.Html("Comments", tracking=True, index=True, compute='_copy_note_data')
    file_upload = fields.Binary(attachment=True, string="Upload Letter", tracking=True, index=True, )
    reply_upload = fields.Binary(attachment=True, string="Upload Final Reply", tracking=True, index=True, )
    create_task = fields.Boolean(default=False)
    upload_pdf = fields.Boolean(default=False, string="Upload PDF File")
    upload_word = fields.Boolean(default=False, string="Upload Word File")
    # upload_excel = fields.Boolean(default=False,string="Upload excel File")
    create_meeting = fields.Boolean(default=False)
    document_ids = fields.One2many("multiple.attachment", 'file_id', string="Additional Document")
    status = fields.Selection([('draft', 'Draft'),
                               ('forward', 'Forward'),
                               ('done', 'Done'),
                               ('lock', 'Lock'),
                               ], default='draft', string="Status", tracking=True, index=True, )

    @api.depends('name', 'version_no')
    def name_get(self):
        result = []
        for rec in self:
            result.append((rec.id, (rec.name or '') + '-' + (rec.version_no or '')))
        return result

    @api.onchange('docx_file')
    def read_docx_file(self):
        if self.docx_file:
            docx_content = base64.b64decode(self.docx_file)
            docx_stream = io.BytesIO(docx_content)
            doc = Document(docx_stream)
            content = []
            for paragraph in doc.paragraphs:
                content.append(paragraph.text)
            self.content = '\n'.join(content)

    @api.constrains('ref_no')
    def _check_unique_name(self):
        for record in self:
            if self.search_count([('ref_no', '=', record.ref_no)]) > 1:
                raise ValidationError("This reference no record as already exist in the system.")

    # def create(self, vals):
    #     # Check constraints before creating a record
    #     self._check_constraints(vals)
    #     return super(ELetter, self).create(vals)

    # def get_job_department_ids(self):
    #     for record in self:
    #         job_ids = record.employee_ids.mapped('job_id.id')
    #         department_ids = record.employee_ids.mapped('department_id.id')

    # def get_current_user_department(self):
    #     pdb.set_trace()
    #     current_user = self.env.user
    #     department = current_user.employee_id.department_id.id
    #     self.current_employee_dep = department

    def send_email(self):
        for rec in self:
            for eml in rec.send_to:
                template_id = self.env.ref('e_filing.e_file_email_templates').id
                template = self.env['mail.template'].sudo().browse(template_id)
                template.email_from = self.sudo().env.user.email
                template.email_to = eml.sudo().work_email
                template.sudo().send_mail(rec.id, force_send=True)


        # template = self.env.ref("e_filing.e_file_email_templates")
        # print(template)
        # for rec in self:
        #     template.send_mail(rec.id, force_send=True, )

    # template_id = self.env.ref('edit_rate_custom.time_sheet_approved_temp').id
    # self.env['mail.template'].browse(template_id).send_mail(approved.id, force_send=True)

    def create_letter_tasks(self):
        self.create_task = True
        project_task = self.env['project.task'].create({
            'name': self.name,
            # Set other required field values
        })
        action = {
            'name': 'Project Task',
            'type': 'ir.actions.act_window',
            'res_model': 'project.task',
            'res_id': project_task.id,
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'current',
        }
        return action

    def view_letter_tasks(self):

        return {
            'name': 'List View',
            'type': 'ir.actions.act_window',
            'res_model': 'project.task',  # The model of the target table
            'view_mode': 'kanban,tree,form',
            'domain': [],  # Optional domain to filter the records in the list view
        }

    def create_meeting_event(self):
        self.create_meeting = True
        meeting_event = self.env['calendar.event'].create({
            'name': self.name,
            # Set other required field values
        })
        action = {
            'name': 'Project Task',
            'type': 'ir.actions.act_window',
            'res_model': 'calendar.event',
            'res_id': meeting_event.id,
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'current',
        }
        return action

    def view_meeting_event(self):

        return {
            'name': 'List View',
            'type': 'ir.actions.act_window',
            'res_model': 'calendar.event',  # The model of the target table
            'view_mode': 'calendar',
            'domain': [],  # Optional domain to filter the records in the list view
        }

    #
    # @api.onchange('department_ids')
    # def _onchange_send_to(self):
    #     for rec in self:
    #         return {'domain':{'send_to':[('ids','in',rec.department_ids.)]}}
    # @api.depends('birthday')
    # def _compute_age(self):
    #
    #     activity = self.env['mail.activity'].browse(activity_id)  # Replace activity_id with the actual ID of the activity
    #
    #     if activity.user_id:
    #         user = activity.user_id
    #         user_name = user.name
    #         user_email = user.email
    #         # ... perform further operations with the user
    #     else:
    #         # Handle the case when no user is assigned to the activity

    def _copy_note_data(self):
        note_datas = ''
        # activity_model = self.env['mail.activity']
        # activity_records = activity_model.search([('res_model', '=', 'e.filing'), ('res_id', '=', self.id)])
        # note_data = '\n'.join(activity_records.mapped('note'))
        for rec in self.message_ids:
            note_datas += rec.author_id.name + ' : ' + rec.body
        # note_datas =self.message_ids.body
        self.description = note_datas

    def forward_btn(self):
        self.send_email()
        self.in_progress = False
        self.sender_id = self.env.user
        # sender_user = self.sender_id
        sender_records_to_move = []
        for rec in self.sender_id:
            sender_records_to_move.append(rec.id)
        # pdb.set_trace()
        record = self.env['res.users'].browse(sender_records_to_move)
        self.employee_track_sender |= record
        # self.sender_id = [(5, 0, 0)]

        send_user = self.send_to.user_id
        records_to_move = []
        for rec in self.send_to:
            records_to_move.append(rec.id)
        record = self.env['hr.employee'].browse(records_to_move)
        self.employee_track |= record
        self.send_to = [(5, 0, 0)]
        for user in send_user:
            if user:
                self.write({'status': "forward"})
                self.env['mail.activity'].create({
                    'res_id': self.id,
                    'res_model_id': self.env['ir.model']._get('e.letter').id,
                    'summary': '',
                    'note': 'Write Your Comments',
                    'user_id': user.id,
                    'activity_type_id': 4,
                    'date_deadline': fields.Date.context_today(self),
                })
            else:
                raise UserError(_('Please Allow the access right to the user'))

        # print('ggggggggggggggggggggg',records_to_move)
        # records_to_move = self.field_from
        # self.employee_track = [(4, record) for record in records_to_move]
        # record = self.env['hr.employee'].browse(records_to_move)
        # self.emp_2 |= record
        # self.em = [(5, 0, 0)]

    def action_lock(self):
        self.status = 'lock'

    def action_done(self):
        self.status = 'done'

    # def unlink(self):
    #     if not self.status == 'draft':
    #         raise UserError(_('You can delete the Records that are in the Draft State.'))
    #     return super(ELetter, self).unlink()


# class InhChatter(models.AbstractModel):
#     _inherit = "e.letter"
#
#     chatter_file_upload = fields.Binary(attachment=True)
#
class SensitivityTable(models.Model):
    _name = 'sensitivity.table'

    name = fields.Char('Name')


class EMeeting(models.Model):
    _name = 'e.meeting'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'E Office'

    ref_no = fields.Char("Ref No", required=True, tracking=True, index=True, )
    name = fields.Char("Subject", required=True, tracking=True, index=True, )
    send_to = fields.Many2many("res.users", string="Send To", required=True, tracking=True, index=True, )
    department_ids = fields.Many2many("hr.department", string="Departments", tracking=True, index=True, )
    description = fields.Html("Description", tracking=True, index=True, )
    parent_id = fields.Many2one("e.letter", string="Versions", required=True, tracking=True, index=True, )

    revisions_name = fields.Many2one("res.users", string="Revision Name", required=True, tracking=True, index=True, )
    letter_date = fields.Date("Letter Date", required=True, tracking=True, index=True, )
    file_upload = fields.Binary(attachment=True, string="Upload Letter", tracking=True, index=True, )
    status = fields.Selection([('draft', 'Draft'),
                               ('forward', 'Forward'),
                               ('done', 'Done'),
                               ('lock', 'Lock'),
                               ], string="Status", tracking=True, index=True, )

    def forward_btn_meeting(self):

        send_user = self.send_to.ids
        for user in send_user:
            if user:
                self.write({'status': "done"})
                self.env['mail.activity'].create({
                    'res_id': self.id,
                    'res_model_id': self.env['ir.model']._get('e.meeting').id,
                    'summary': 'Submitted For Perusal And Approval',
                    'note': 'Write Your Comments',
                    'user_id': user,
                    'activity_type_id': 4,
                    'date_deadline': fields.Date.context_today(self),
                })
            else:
                raise UserError(_('Please Allow the access right to the user'))

    def action_lock(self):
        self.status = 'lock'

    def action_done(self):
        self.status = 'done'

    def unlink(self):
        if not self.status == 'draft':
            raise UserError(_('You can delete the Records that are in the Draft State.'))
        return super(EMeeting, self).unlink()


class EFiling(models.Model):
    _name = 'e.filing'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'E Office'
    # _rec_name = 'parent_id'

    ref_no = fields.Char("Ref No", required=True, tracking=True, index=True, )
    sender_id = fields.Many2one('res.users', string='Sender', )
    sensitivity_id = fields.Many2one("sensitivity.table", string="Sensitivity Type")
    name = fields.Char("Subject", required=True, tracking=True, index=True, )
    send_to = fields.Many2many("hr.employee", string="Send To", tracking=True, index=True, )
    department_ids = fields.Many2many("hr.department", string="Departments", tracking=True, index=True, )
    letter_date = fields.Date("File Date", tracking=True, index=True, )
    version_no = fields.Char("Version No")
    in_progress = fields.Boolean('Working InProgress', default=False, tracking=True, index=True, )
    parent_id = fields.Many2one("e.letter", string="If Any Previous (version)", tracking=True, index=True, )
    revisions_name = fields.Many2one("res.users", string="Revision Name", )
    employee_track_sender = fields.Many2many("res.users", 'employee_track_senderss', 'employee_track_idsss',
                                             string="Employee Track Sender", tracking=True, index=True, )
    employee_track = fields.Many2many("hr.employee", 'employee_tracksss', 'employee_track_idsss',
                                      string="Employee Track",
                                      tracking=True, index=True, )
    description = fields.Html("Paragraphs", tracking=True, index=True, compute='_copy_note_data')
    file_upload = fields.Binary(attachment=True, string="Upload Letter", tracking=True, index=True, )
    status = fields.Selection([('draft', 'Draft'),
                               ('forward', 'Forward'),
                               ('done', 'Done'),
                               ('lock', 'Lock'),
                               ], default='draft', string="Status", tracking=True, index=True, )
    document_ids = fields.One2many("multiple.document", 'file_id', string="Additional Document")
    paragraph_ids = fields.One2many("multiple.paragraph", 'pera_id', string="Paragraph", tracking=True)
    create_task = fields.Boolean(default=False)
    create_meeting = fields.Boolean(default=False)

    def send_email(self):
        for rec in self:
            for eml in rec.send_to:
                template_id = self.env.ref('e_filing.e_filing_email_templates').id
                template = self.env['mail.template'].sudo().browse(template_id)
                template.email_from = self.sudo().env.user.email
                template.email_to = eml.sudo().work_email
                template.sudo().send_mail(rec.id, force_send=True)



    @api.depends('name', 'version_no')
    def name_get(self):
        result = []
        for rec in self:
            result.append((rec.id, (rec.name or '') + '-' + (rec.version_no or '')))
        return result

    def create_file_tasks(self):
        self.create_task = True
        project_task = self.env['project.task'].create({
            'name': self.name,
            # Set other required field values
        })
        action = {
            'name': 'Project Task',
            'type': 'ir.actions.act_window',
            'res_model': 'project.task',
            'res_id': project_task.id,
            'view_mode': 'kanban',
            'view_type': 'kanban',
            'target': 'current',
        }
        return action

    def view_file_tasks(self):

        return {
            'name': 'List View',
            'type': 'ir.actions.act_window',
            'res_model': 'project.task',  # The model of the target table
            'view_mode': 'kanban,tree,form',
            'domain': [],  # Optional domain to filter the records in the list view
        }

    def create_meeting_event(self):
        self.create_meeting = True
        meeting_event = self.env['calendar.event'].create({
            'name': self.name,
            # Set other required field values
        })
        action = {
            'name': 'Project Task',
            'type': 'ir.actions.act_window',
            'res_model': 'calendar.event',
            'res_id': meeting_event.id,
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'current',
        }
        return action

    def view_meeting_event(self):

        return {
            'name': 'List View',
            'type': 'ir.actions.act_window',
            'res_model': 'calendar.event',  # The model of the target table
            'view_mode': 'calendar',
            'domain': [],  # Optional domain to filter the records in the list view
        }

    def _copy_note_data(self):
        note_datas = ''
        # activity_model = self.env['mail.activity']
        # activity_records = activity_model.search([('res_model', '=', 'e.filing'), ('res_id', '=', self.id)])
        # note_data = '\n'.join(activity_records.mapped('note'))
        for rec in self.message_ids:
            note_datas += rec.author_id.name + ' : ' + rec.body
        # note_datas =self.message_ids.body
        self.description = note_datas

    def forward_btn(self):

        self.send_email()
        self.in_progress = False
        self.sender_id = self.env.user
        # sender_user = self.sender_id
        sender_records_to_move = []
        for rec in self.sender_id:
            sender_records_to_move.append(rec.id)
        # pdb.set_trace()
        record = self.env['res.users'].browse(sender_records_to_move)
        self.employee_track_sender |= record

        send_user = self.send_to.user_id
        records_to_move = []
        for rec in self.send_to:
            records_to_move.append(rec.id)
        record = self.env['hr.employee'].browse(records_to_move)
        self.employee_track |= record
        self.send_to = [(5, 0, 0)]

        for user in send_user:
            if user:
                self.write({'status': "forward"})
                self.env['mail.activity'].create({
                    'res_id': self.id,
                    'res_model_id': self.env['ir.model']._get('e.filing').id,
                    'summary': '',
                    'note': 'Write Your Comments',
                    'user_id': user.id,
                    'activity_type_id': 4,
                    'date_deadline': fields.Date.context_today(self),
                })
            else:
                raise UserError(_('Please Allow the access right to the user'))

    # def action_close_dialog(self):
    #     print("ssssssssssssssssdddddddddddddddddddddd")
    #     target_model = self.env['e.filing']
    #     note_data = self.env['mail.activity'].search(
    #         [('res_model', '=', 'e.filing'), ('res_id', '=', self.id)]).mapped('note')
    #     target_model.write({'description': '\n'.join(note_data)})
    #     pdb.set_trace()

    def action_lock(self):
        self.status = 'lock'

    def action_done(self):
        self.status = 'done'

    # def unlink(self):
    #     if not self.status == 'draft':
    #         raise UserError(_('You can delete the Records that are in the Draft State.'))
    #     return super(EFiling, self).unlink()


class MultipleDocument(models.Model):
    _name = "multiple.document"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'E Office'

    file_id = fields.Many2one("e.filing")
    name = fields.Char("Title")
    description = fields.Char("Description")
    # upload_file = fields.Binary(attachment=True, string="Upload Letter", )
    upload_file = fields.Many2many('ir.attachment', string="Upload Attachments")


class Demo(models.Model):
    _name = "demo.file"

    name = fields.Char("Title")
    description = fields.Char("Description")
    document_idss = fields.One2many("one.many", 'file_idss', string="Additional Document")
    upload_file = fields.Binary(attachment=True, string="Upload Letter", )

    def demo_btn(self):
        wb = xlrd.open_workbook(file_contents=base64.decodebytes(self.upload_file))
        sheet = wb.sheets()[0]
        for row in range(sheet.nrows):
            if row == 0:
                continue

    def _create_journal_entry(self, record):
        code = int(record[0])
        account_id = self.env['demo.file'].search([], limit=1)
        # if not account_id:
        #     raise UserError(_("There is no account with code %s.") % code)
        # partner_id = self.env['res.partner'].search([('name', '=', record[2])], limit=1)
        # if not partner_id:
        #     partner_id = self.env['res.partner'].create({
        #         'name': record[1],
        #         'customer': True,
        #     })
        line_ids = {
            # 'account_id': account_id.id,
            # 'partner_id': partner_id.id,
            'name': record[1],
            'debit': record[4],
            'credit': record[5],
        }
        return line_ids


class Demoone(models.Model):
    _name = "one.many"

    file_idss = fields.Many2one("demo.file")
    name = fields.Char("Title")
    roll = fields.Char("roll")
    classes = fields.Char("class")


class MultipleAttachment(models.Model):
    _name = "multiple.attachment"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'E Office'

    file_id = fields.Many2one("e.letter")
    name = fields.Char("Description")
    # upload_file = fields.Binary(attachment=True, string="Upload Attachments", )
    upload_file = fields.Many2many('ir.attachment', string="Upload Attachments")



class MultipleParagraph(models.Model):
    _name = "multiple.paragraph"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'E Office'

    pera_id = fields.Many2one("e.filing")
    # sequence = fields.Char(string='Sequence', readonly=True, copy=False, default=lambda self: ('New'))
    sequence = fields.Char(string='Para No.', tracking=True, index=True, )
    name = fields.Html("Description", tracking=True, index=True, )
    activesss = fields.Boolean(default=False)

    def submit_paragraph(self):
        self.activesss = True
        self.pera_id.description += '\n' + self.sequence + "  :  " + self.name + '\n'

# class MailActivity(models.Model):
#     _inherit = 'mail.activity'
#
#     def action_close_dialog(self):
#         print("ssssssssssssssssdddddddddddddddddddddd")
#         target_model = self.env['e.filing']
#         note_data = self.env['mail.activity'].search([('res_model', '=', 'mail.activity'), ('res_id', '=', self.id)]).mapped('note')
#         target_model.write({'description': '\n'.join(note_data)})
#         pdb.set_trace()
