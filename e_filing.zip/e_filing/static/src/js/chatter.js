//// my_module/static/src/js/chatter.js
//odoo.define('e_filing.chatter', function (require) {
//    'use strict';
//
//    var Chatter = require('mail.Chatter');
//
//    Chatter.include({
//        events: _.extend({}, Chatter.prototype.events, {
//            // Handle the file field change event
//            'change #chatter_file_upload': '_onCustomFileFieldChange',
//        }),
//
//        // Handle the file field change event
//        _onCustomFileFieldChange: function (ev) {
//            var files = ev.target.files;
//            // Handle the selected files here
//            // You can perform further actions like uploading or processing the files
//        },
//    });
//
//    return Chatter;
//});

odoo.define('e_filing.ChatterExtension', function (require) {
    'use strict';

    var Chatter = require('mail.Chatter');

    var ChatterExtension = Chatter.extend({
        // Add the file field in the template
        template: 'e_filing.ChatterExtension',

        // Handle the file field change event
        _onCustomFileFieldChange: function (ev) {
            var files = ev.target.files;
            // Handle the selected files here
            // You can perform further actions like uploading or processing the files
        },
    });

    return ChatterExtension;
});