odoo.define('e_filing.pdf_viewer', function(require) {
    'use strict';

    var core = require('web.core');
    var FieldBinaryFile = core.form_widget_registry.get('binary_file');
    var PdfViewer = FieldBinaryFile.extend({
        template: 'e_filing.PdfViewer',
        start: function() {
            this.$el.html('<object data="data:application/pdf;base64,' + this.get('value') + '" type="application/pdf" width="100%" height="200"></object>');
            return this._super.apply(this, arguments);
        },
    });

    core.form_widget_registry.add('pdf_viewer', PdfViewer);

    return {
        PdfViewer: PdfViewer,
    };
});
